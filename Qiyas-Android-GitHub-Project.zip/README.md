# قياسات - إدارة المواد (Android APK)

هذا مشروع أندرويد يفتح تطبيق قياسات الموجود في `app/src/main/assets/index.html` داخل WebView، ويُبنى تلقائياً عبر GitHub Actions.

## طريقة الاستخدام
1. ارفع محتويات هذا المجلد إلى جذر مستودع GitHub (وليس ملف ZIP فقط).
2. تأكد أن اسم الفرع `main`.
3. افتح تبويب Actions وشغّل `Build Qiyas APK` عبر Run workflow، أو ادفع Commit جديد.
4. بعد نجاح البناء، افتح تشغيل الـ workflow وانزل إلى Artifacts.
5. حمّل `Qiyas-APK` ثم فك الضغط عن الملف ZIP لتحصل على `app-debug.apk`.

هذا APK تجريبي (debug) قابل للتثبيت، وليس إصداراً موقعاً للنشر في المتجر.
